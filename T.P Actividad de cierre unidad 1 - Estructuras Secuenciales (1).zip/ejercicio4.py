radio_círculo=float(input("Ingrese el radio del círculo:"))
pi = 3.1416
area = pi*(radio_círculo**2)
perimetro = 2*radio_círculo*pi
print(f"El area del círculo es {area} y el perímetro es {perimetro}")
print ("Hola Mundo!") 

nombre = input("Ingrese su nombre:")
print(f"Hola {nombre}!")
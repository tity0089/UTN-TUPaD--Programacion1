segundos_cant= float(input("Ingrese la cantidad de segundos:"))
cant_horas= round(segundos_cant/3600, 2)
print(f"La cantidad de segundos ingresados es equivalente a {cant_horas} horas")
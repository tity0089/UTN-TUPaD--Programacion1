altura=float(input("Ingrese su altura:"))
peso=float(input("Ingrese su peso:"))
imc=peso/altura**2
print("Su indice de masa corporal es:", imc)
temp_cel= float(input("Ingrese la temperatura en celsius:"))
temp_fahr =round((9/5)*temp_cel+32, 2)
print(f"La temperatura es {temp_fahr}°F")

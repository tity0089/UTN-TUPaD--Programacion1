num=int(input("Ingrese el primer numero:"))
num2=int(input("Ingrese el segundo numero:"))
num3=int(input("Ingrese el tercer numero:"))
pro_me=(num+num2+num3)/3
print(f"El promedio es:{pro_me}")